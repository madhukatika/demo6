After installation packages 
Create login component and create account component
Refer backend folder for parameters
Flow after creating account, login with same email and password
Response will be a token
Send that token with request,like it's done in fetch request 
