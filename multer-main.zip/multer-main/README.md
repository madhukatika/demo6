# multer
After downloading both the files, install the packages
npm i (in backend and client folders)
