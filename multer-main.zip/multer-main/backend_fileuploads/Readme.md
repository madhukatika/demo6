Hello guys,after installing packages,if you want to add additional features,
The Model is already available you can add the features,
One important thing, create ".env" file
Add
 MONGO_URL=YOUR DB URL
PORT=5000
SECRET=8
